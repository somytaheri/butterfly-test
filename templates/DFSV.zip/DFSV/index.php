<?php defined( '_JEXEC' ) or die( 'Restricted access' );?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" 
   xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<jdoc:include type="head" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/DFSV/css/style.min.css" type="text/css" />
<script src="<?php echo $this->baseurl ?>/templates/DFSV/js/main.min.js"></script>
</head>
<body>
<jdoc:include type="modules" name="search" /> 
<jdoc:include type="component" />
  <img src="<?php echo $this->baseurl ?>/templates/DFSV/images/icons/FB.png"/>
  <img src="<?php echo $this->baseurl ?>/images/banners/site/banner-1.png"/>
  <img src="<?php echo $this->baseurl ?>/images/news/news.png"/>
<jdoc:include type="modules" name="bottom" />
</body>